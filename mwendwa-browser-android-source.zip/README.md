# Mwendwa Browser 1.6

A personal Android browser created for Kelvin Mwendwa, with a navy and gold identity and an M crest. Android 10 or newer is required. Browsing uses the phone's Android System WebView; no separate browser engine is bundled.

## Install

Open MwendwaBrowser.apk on your phone, permit installation from the app that opened it if Android asks, and select Install. Keep Android System WebView updated through Google Play. This app needs your existing Wi-Fi or mobile internet.

## Features

- Address and search bar; Google, Bing or DuckDuckGo search.
- Eight tabs, saved tab URLs, bookmarks and a local history of the latest 300 pages.
- Confirmed file downloads through Android Download Manager.
- Find in page, share page, long press link actions and optional default browser selection.
- Desktop user agent, text scaling from 80% to 160%, supported website darkening.
- Fullscreen web video, user-selected file uploads and speech search through an installed speech app.
- Ad blocking enabled by default, including 6,541 ad/tracker host rules, common banner hiding, popup window blocking, per-site exceptions and a blocked-request counter. Settings → Ad blocking opens its controls.
- Invalid certificate connections rejected; mixed content blocked; third-party cookies disabled.
- Clear history, website storage, cache and cookies together; bookmarks and downloads kept.
- Native launcher logo; scalable SVG and 1024-pixel PNG logo in brand/.

## How to use

The house returns to the start page. The top field accepts searches or addresses. The bottom Back arrow returns to the previous page; Forward is in the menu. The star saves a bookmark, the number opens tabs and the menu opens other features. Settings contains search engine, text size, darkening, tracker blocklist and clearing controls.

## Privacy and limits

History, bookmarks and last-open tab URLs are stored in this app's private local storage. Tabs share cookies and website storage. Closing a tab does not erase browsing data. No incognito isolation, VPN, independent password manager, sync backend or built-in analytics is included. Search services and websites receive requests as usual; speech search uses the phone's speech service. An HTTPS connection is not proof that a site is trustworthy. Explicit HTTP addresses are supported and marked with an exclamation point.

Website camera, microphone and location requests are disabled. Some embedded-browser sign-ins, popups, DRM/video services, blob downloads and advanced sites may require a full browser. Ad blocking cannot remove every ad. Same-domain ads, in-video ads, service-worker activity and requests outside WebView interception can escape filtering. Popup blocking also prevents legitimate target-blank windows; long press links to open a new tab, or allow that site. Ad blocking may break some sites. The bundled host-list snapshot is updated with app releases, not automatically. Darkening depends on the installed WebView. Live website behavior, file uploads, voice recognition, downloads and Android installation have not been tested on a physical phone or emulator in this build environment. This release is not an audited replacement for an established browser.

## Build with Android Studio

Open this folder as a project, use JDK 17, allow Gradle sync, and install Android SDK Platform 35. Gradle wrapper 8.9 and Android Gradle Plugin 8.7.3 are included/configured. No third-party app libraries are required.

Windows: `gradlew.bat assembleRelease`

macOS/Linux: `./gradlew assembleRelease`

Output: `app/build/outputs/apk/release/app-release.apk`

Alternatively, install JDK 17, SDK Platform 35 and Build Tools 35.0.0, then run `python build_apk.py /path/to/Android/Sdk`. This manual route was used to produce the delivered APK. Increase versionCode/versionName in both app/build.gradle and build_apk.py for future updates.

The signing/ directory contains the personal signing key and its credentials so future versions can update this installation. Keep this archive private. Remove signing/ before publishing source publicly; preserve a private backup to retain update compatibility. The .gitignore excludes signing/.

## Validation performed

- Java 17 source compilation against Android API 35.
- D8 dex generation with minimum Android API 29.
- Android resource/manifest packaging; package name, launcher and SDK values inspected.
- APK signature verified with apksigner; ZIP alignment verified with zipalign.
- Android lint checks NewApi, InlinedApi and MissingPermission: no issues found.
- Start-page layout rendered at 393px and 320px widths, no horizontal overflow.
- Start-page screenshot visually reviewed; reviewed internally.

These checks do not replace installation and usage tests on Android.

## Developer references

- https://developer.android.com/reference/android/webkit/WebView
- https://developer.android.com/reference/android/webkit/WebSettings
- https://developer.android.com/privacy-and-security/risks/webview-unsafe-file-inclusion

Gradle wrapper files originate from https://github.com/gradle/gradle/tree/v8.9.0 and are licensed under Apache-2.0 (https://www.apache.org/licenses/LICENSE-2.0).

## Ad-blocking data and attribution

AdAway default hosts list, downloaded 24 October 2026 from https://raw.githubusercontent.com/AdAway/adaway.github.io/master/hosts.txt. Contributors include Kicelo, Dominik Schuermann, and contributors listed in the upstream commit history. Licensed CC Attribution 3.0: https://creativecommons.org/licenses/by/3.0/. The original file and attribution header are preserved unmodified in app/src/main/assets/adaway-hosts.txt. AdBlocker.java converts its host entries to an in-memory lookup table and adds six host families. Cosmetic rules are implemented locally in MainActivity.java.

Validation for v1.1 includes 13 host-matching checks against fixture and bundled rules, including subdomains, case/trailing-dot handling, sibling-domain safety and ordinary content hosts. Cosmetic rules are checked in a browser fixture for initial and dynamically inserted ads. APK rebuilt with versionCode 2 and the original signing key for an in-place update; no on-device or emulator usage testing has been performed.

## Version 1.2: experimental YouTube helper

Enabled by default in Menu → Settings → YouTube ad helper. Operates only on youtube.com and its subdomains while ad blocking is active and the current host has no exception. Hides specific YouTube banner/promotion containers and clicks visible, enabled Skip ad controls only inside a player marked as showing an ad. It never seeks, changes playback speed, changes volume, or pauses the video. Turning it off removes its timers, observers and styles. This does not affect the standalone YouTube app.

This is ad-skipping assistance, not reliable in-video ad blocking. Unskippable ads can still play. Site layout changes may stop the helper working. Desktop and mobile synthetic fixtures passed checks for active-ad gating, disabled/hidden buttons, duplicate installation, unchanged video state, host scoping, and disable cleanup. Live YouTube ads and Android installation/playback have not been tested. Version code is 3; the original signing key is retained for an in-place update.

## Version 1.3: Discover

Tap ✦ Discover on the bottom navigation bar, use Menu → Discover, or select the start-page Discover button. An existing Discover tab is reused; if all eight tabs are open, Discover opens in the current tab.

Five sections: Google trending searches, news, movies, songs and TikTok. Kenya is the default edition, with United States, United Kingdom, Nigeria and South Africa options. Google Trends and Google News RSS are retrieved on demand over HTTPS with an 8-second connect/read timeout, fixed source hosts, bounded response sizes and no browser cookies. Only HTTPS item links are displayed. XML DTDs/entities are rejected, remote titles are rendered as text, and no JavaScript-to-native bridge is exposed. RSS item titles, publisher, publication time and traffic estimates (where provided) link to the source or a search for the trend.

Movie, music and TikTok lists are recent news headlines; their in-app lists are not platform popularity rankings. Live-source buttons open IMDb Most Popular Movies, YouTube Charts and TikTok’s current trend dashboard. Charts retain their own country/period selectors and may require sign-in or verification. No private TikTok API, movie API key or scraped ranking is claimed.

Feeds refresh when opened and every five minutes while visible, with manual Refresh. Switching away or pausing the app suspends scheduled feed refreshes. Each provider controls its publishing interval, so this does not promise instant or complete trend coverage. Successful feeds are cached in localStorage with fetch timestamps. A failed refresh explicitly labels cached results or states that live data is unavailable. These caches are erased by Clear browsing data. Source publication times and fetch time are separate.

Validation: retrieved and parsed live Google Trends Kenya and Google News feeds for news/movies/music/TikTok; RSS metadata/namespace, entity/encoding rejection and item-limit checks; five-category UI, country persistence, HTTPS-link/title safety, cached offline state, five-minute visible refresh, native hide/show suspension, 320/393-pixel layout and screenshot inspection; Android API lint, APK signature and ZIP alignment checks. Version code 4; signed with the original key. Full Android installation/network/playback behavior still requires phone testing.

Source references:
- https://support.google.com/trends/answer/3076011
- https://news.google.com/
- https://www.imdb.com/chart/moviemeter/
- https://support.google.com/youtube/answer/9014376
- https://ads.tiktok.com/creative/creativeCenter/trends

## Version 1.4: Free Movies

Tap ▶ Movies in the bottom bar, Menu → Free Movies, or the start-page movie button. The bottom bar retains six touch targets; Forward moved into the menu. The movie tab reuses its existing tab if present, or opens in the current tab if the eight-tab limit has been reached.

Search movie titles, choose a genre, sort by popularity (source downloads) or recently added, and page through results. The search uses Internet Archive’s feature_films collection and restricts licenseurl metadata to Creative Commons Public Domain Mark, CC0 and the older CC public-domain dedication URLs. Licensing information is uploader-provided, not independently verified. These source labels do not establish universal copyright status. This is a limited catalog and does not contain every movie or promise recent theatrical releases.

The local search/library page contains no advertisements. The existing browser ad blocker remains active when opening a film. Watch opens the official archive.org/embed/IDENTIFIER source player in this browser; Details & licence opens the source record. Streaming behavior, playback availability, sign-in requirements and any source-provided elements remain controlled by the source; ad-free playback on all providers is not guaranteed. No files are re-hosted, no paid catalogs or access controls are bypassed, and films are not downloaded automatically. Streaming uses the phone’s internet/data.

Queries go to archive.org over HTTPS with 10-second connection/read timeouts and bounded JSON responses. Title input is bounded, normalized and quoted; genre/sort choices are fixed enums. Item identifiers and licence URLs are checked again after search. Frontend links and image URLs are restricted to the expected HTTPS archive.org paths; titles use textContent. Source titles, thumbnails, years, creator names and licensing labels are displayed as supplied. Current search/filter/page state is retained in the tab URL.

Validation: public catalog query returned matching source listings; a sample official embed page was retrieved and contained player references; 15 title-query/licence safety checks; actual API JSON parsing and rejection of invalid IDs/licences; UI title search, filters, ordering, paging, empty/unavailable states, source links, safe text rendering and 320/393px widths; screenshot inspection, Android API lint, signature and ZIP alignment verification. Playback of a full film and installation on an Android device have not been tested. Version code 5; original signing key retained.

References:
- https://archive.org/advancedsearch.php
- https://archive.org/developers/md-read.html
- https://archivesupport.zendesk.com/hc/en-us/articles/360017808151-Movies-and-Videos-A-Basic-Guide
- https://archivesupport.zendesk.com/hc/en-us/articles/360018377531-Movies-and-Videos-Tips-Troubleshooting

## Version 1.5: loading and playback fixes

Movie browsing now uses compact rows with an immediately visible Play movie button. Eight results are requested per page instead of twelve. Covers are disabled by default; enabling Show covers opts into thumbnail requests. Successful result pages are kept in localStorage for 15 minutes and reused without a network request on warm reopening. Refresh explicitly bypasses that cache, and a failed update keeps existing results with a clear saved-results label. Clear browsing data removes this cache too.

Catalog queries require a source-listed MP4 format. This excludes some stale records whose movie file has been removed, but the source index itself can still be stale. On Play movie, MainActivity intercepts a user-initiated local play link and opens the private MoviePlayerActivity. No JavaScript-to-native bridge was added. The Activity resolves current item metadata on a worker thread, verifies source collection, public-domain/CC0 label and availability flags, and looks for public MP4 files. Missing video files produce a clear error instead of opening a web-player page with nothing to play.

The dedicated Android VideoView player has a visible video area, Play/Pause, seek bar, elapsed/total time, ±10-second controls, retry, file selection, fullscreen and Back to movies. Fullscreen uses Android MediaController overlay controls with a persistent Exit button. Source-connection, stream-opening and buffering states are distinct; slow-loading messages do not overwrite completed error states. Playback pauses in the background and releases video/network UI resources when closed.

Stream selection prefers a near-full-duration track, an explicitly H.264-labelled MP4 where supplied, then a smaller file among equivalent choices. It does not transcode or create adaptive streams. Choosing another file restarts it. The player opens the source MP4 directly over HTTPS; it does not load the Archive web-player page or third-party scripts. Source speed, file availability and codec compatibility remain external constraints. Some older files have several megabytes of container metadata to load before playback can start.

Validation: 17 movie query/licence checks; real source metadata checks, including a listing with no video and a listing with two MP4 files; path/private-file/unsupported-format rejection and stream-order checks; live MP4 byte-range retrieval, H.264/AAC metadata probing and decoding one video frame; UI checks for Play visibility, zero cover requests by default, cache reuse without a network call, manual refresh, paging, filters, no-results/unavailable states and narrow-screen layout; Java compilation, Android API lint, APK signing/alignment checks. Native Android installation, MediaPlayer behavior, rotation and full-film playback have not been verified on a phone or emulator. Version code 6, original signing key retained.

## Version 1.6: Deep Search

Tap ⌕ Deep in the bottom bar or Menu → Deep Search. Save bookmark moved to the menu to retain six touch targets. The workspace offers ten public search sources, exact phrases, excluded words, five website scopes, document formats, country bias, Google dates/type filters, a query preview, twelve locally saved searches and opening up to four selected sources. The eight-tab limit still applies; close tabs to open additional sources.

Google receives all advanced filters; Bing also receives country bias. Academic/reference/video sources use the topic and exact phrase. The feature builds queries and opens provider results rather than generating an AI research report. Deep open actions require a user gesture from the local Deep Search page and accept only HTTPS URLs on the known provider hosts, without user info or custom ports. Saved searches are removed by Clear browsing data.

Validation: query and provider URL tests; responsive UI at 320/393/1280 px, save/restore/delete, max-four selection, malformed domains/dates and safe rendering; Java build, Android API lint, signature and alignment checks. Version code 7 with the original signing key. Android installation and actual search-result behavior require phone testing.
