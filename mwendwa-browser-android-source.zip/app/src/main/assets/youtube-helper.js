(function () {
    'use strict';
    if (!/(^|\.)youtube\.com$/.test(location.hostname)) return;
    if (window.__mwendwaYouTubeHelper) return;
    var styleId = 'mwendwa-youtube-ad-style';
    var observer = null, pending = null, lastClick = 0, stopped = false;
    var css = 'ytd-ad-slot-renderer,ytd-display-ad-renderer,ytd-promoted-sparkles-web-renderer,' +
        'ytd-promoted-video-renderer,ytm-promoted-sparkles-web-renderer,ytm-companion-ad-renderer,' +
        '#masthead-ad,.ytp-ad-overlay-container{display:none!important;}';
    function visible(node) {
        return node && !node.disabled && node.getAttribute('aria-disabled') !== 'true' &&
            node.getClientRects().length > 0 && getComputedStyle(node).visibility !== 'hidden' &&
            getComputedStyle(node).display !== 'none';
    }
    function tick() {
        pending = null;
        if (stopped || document.hidden) return;
        if (document.head && !document.getElementById(styleId)) {
            var style = document.createElement('style');
            style.id = styleId; style.textContent = css; document.head.appendChild(style);
        }
        // Only click a known skip control in a player explicitly showing an ad.
        // Never seek, mute, speed up, or pause the underlying video.
        var players = document.querySelectorAll('.html5-video-player.ad-showing,.html5-video-player.ad-interrupting');
        for (var p = 0; p < players.length; p++) {
            var controls = players[p].querySelectorAll('.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-skip-ad-button');
            for (var i = 0; i < controls.length; i++) {
                if (visible(controls[i]) && Date.now() - lastClick > 1500) {
                    controls[i].click(); lastClick = Date.now(); return;
                }
            }
        }
    }
    function schedule() { if (!pending && !stopped) pending = setTimeout(tick, 150); }
    observer = new MutationObserver(schedule);
    observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true,
        attributeFilter: ['class', 'disabled', 'aria-disabled', 'style'] });
    var timer = setInterval(tick, 1500);
    function stop() {
        stopped = true; clearInterval(timer); clearTimeout(pending); observer.disconnect();
        document.removeEventListener('visibilitychange', schedule);
        window.removeEventListener('pagehide', stop);
        var style = document.getElementById(styleId); if (style) style.remove();
        delete window.__mwendwaYouTubeHelper;
    }
    window.__mwendwaYouTubeHelper = { stop: stop };
    document.addEventListener('visibilitychange', schedule);
    window.addEventListener('pagehide', stop);
    tick();
}());
