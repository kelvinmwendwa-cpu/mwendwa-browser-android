package com.mwendwa.browser;

import java.io.*;
import java.net.*;
import java.util.*;
import org.json.*;

/** Public RSS requests only. Never accepts a caller-supplied upstream URL. */
public final class DiscoverFeed {
    private static final Map<String,String> COUNTRIES=new HashMap<>();
    static {COUNTRIES.put("KE","Kenya");COUNTRIES.put("US","United States");COUNTRIES.put("GB","United Kingdom");COUNTRIES.put("NG","Nigeria");COUNTRIES.put("ZA","South Africa");}
    public static String load(String category,String region)throws Exception{
        if(!COUNTRIES.containsKey(region))region="KE";
        String locale="en-"+region,base="https://news.google.com/rss",source="Google News",target;
        switch(category){
            case "trending":target="https://trends.google.com/trending/rss?geo="+region;source="Google Trends";break;
            case "news":target=base+"?hl="+locale+"&gl="+region+"&ceid="+region+":en";break;
            case "movies":target=searchUrl("movies OR movie trailers when:2d",region);break;
            case "music":target=searchUrl(COUNTRIES.get(region)+" music OR songs when:2d",region);break;
            case "tiktok":target=searchUrl("TikTok trends OR TikTok music when:2d",region);break;
            default:throw new IllegalArgumentException("Unknown category");
        }
        byte[] data=download(target);RssFeed.Result feed=RssFeed.parse(data);
        if(feed.entries.isEmpty())throw new IOException("This source returned no items.");
        JSONArray items=new JSONArray();for(RssFeed.Entry entry:feed.entries){
            String link=entry.link;
            if(category.equals("trending"))link="https://www.google.com/search?q="+URLEncoder.encode(entry.title,"UTF-8");
            URI uri;try{uri=new URI(link);}catch(URISyntaxException e){continue;}
            if(!"https".equalsIgnoreCase(uri.getScheme())||uri.getHost()==null||uri.getUserInfo()!=null)continue;
            items.put(new JSONObject().put("title",entry.title).put("url",link).put("published",entry.published).put("publisher",entry.publisher.isEmpty()?source:entry.publisher).put("traffic",entry.traffic));
        }
        if(items.length()==0)throw new IOException("This source returned no usable links.");
        return new JSONObject().put("category",category).put("region",region).put("source",source).put("sourceUpdated",feed.updated).put("fetchedAt",System.currentTimeMillis()).put("items",items).toString();
    }
    private static String searchUrl(String query,String region)throws Exception{return "https://news.google.com/rss/search?q="+URLEncoder.encode(query,"UTF-8")+"&hl=en-"+region+"&gl="+region+"&ceid="+region+":en";}
    private static byte[] download(String target)throws Exception{
        URL url=new URL(target);
        for(int hop=0;hop<4;hop++){
            if(!url.getProtocol().equals("https")||!(url.getHost().equals("news.google.com")||url.getHost().equals("trends.google.com")))throw new IOException("Unexpected source redirect");
            HttpURLConnection connection=(HttpURLConnection)url.openConnection();
            connection.setConnectTimeout(8000);connection.setReadTimeout(8000);connection.setUseCaches(false);connection.setInstanceFollowRedirects(false);
            connection.setRequestProperty("Cache-Control","no-cache");connection.setRequestProperty("Accept","application/rss+xml, application/xml, text/xml");connection.setRequestProperty("User-Agent","MwendwaBrowser/1.3 RSS Reader");
            try{int status=connection.getResponseCode();
                if(status>=300&&status<400){String next=connection.getHeaderField("Location");if(next==null)throw new IOException("Invalid source redirect");url=new URL(url,next);continue;}
                if(status!=200)throw new IOException("Source unavailable");
                try(InputStream in=connection.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
                    byte[] buffer=new byte[8192];int n,total=0;while((n=in.read(buffer))!=-1){total+=n;if(total>2097152)throw new IOException("Source response too large");out.write(buffer,0,n);}return out.toByteArray();
                }
            }finally{connection.disconnect();}
        }throw new IOException("Too many source redirects");
    }
}
