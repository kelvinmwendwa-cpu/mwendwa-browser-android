package com.mwendwa.browser;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Read-only host matcher. No browsing data or list updates are sent anywhere. */
public final class AdBlocker {
    private final Set<String> hosts;
    public AdBlocker(InputStream stream) throws IOException {
        Set<String> loaded = new HashSet<>();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String body = line.split("#", 2)[0].trim();
                if (body.isEmpty()) continue;
                String[] fields = body.split("\\s+");
                if (fields.length < 2 || !(fields[0].equals("0.0.0.0") || fields[0].equals("127.0.0.1") || fields[0].equals("::1"))) continue;
                for (int i = 1; i < fields.length; i++) {
                    String host = normalize(fields[i]);
                    if (host.contains(".") && host.matches("[a-z0-9.-]+") && !host.equals("localhost.localdomain")) loaded.add(host);
                }
            }
        }
        loaded.addAll(Arrays.asList("doubleclick.net", "google-analytics.com", "googlesyndication.com", "connect.facebook.net", "scorecardresearch.com", "ads-twitter.com"));
        hosts = Collections.unmodifiableSet(loaded);
    }
    public int size() { return hosts.size(); }
    public static String normalize(String host) {
        if (host == null) return "";
        String normalized = host.toLowerCase(Locale.ROOT);
        while (normalized.endsWith(".")) normalized = normalized.substring(0, normalized.length() - 1);
        return normalized;
    }
    public boolean blocks(String host) {
        String candidate = normalize(host);
        while (candidate.contains(".")) {
            if (hosts.contains(candidate)) return true;
            candidate = candidate.substring(candidate.indexOf('.') + 1);
        }
        return false;
    }
}
