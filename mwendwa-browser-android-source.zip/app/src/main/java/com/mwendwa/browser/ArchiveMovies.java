package com.mwendwa.browser;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import org.json.*;

public final class ArchiveMovies {
    private static String text(JSONObject item,String field){Object value=item.opt(field);if(value instanceof JSONArray)return ((JSONArray)value).optString(0,"");return value==null||value==JSONObject.NULL?"":String.valueOf(value);}
    public static String parse(String json,String term,int page)throws Exception{
        JSONObject response=new JSONObject(json).getJSONObject("response");JSONArray rows=response.getJSONArray("docs"),items=new JSONArray();
        for(int i=0;i<Math.min(rows.length(),8);i++){JSONObject row=rows.optJSONObject(i);if(row==null)continue;String id=text(row,"identifier"),title=text(row,"title"),license=text(row,"licenseurl"),label=MovieQuery.license(license);
            if(!id.matches("[A-Za-z0-9][A-Za-z0-9_.-]{0,199}")||title.isEmpty()||label.isEmpty())continue;
            items.put(new JSONObject().put("id",id).put("title",title).put("year",text(row,"year")).put("creator",text(row,"creator")).put("license",label).put("licenseUrl",license.replaceFirst("^http:","https:")).put("sourceUrl","https://archive.org/details/"+id).put("watchUrl","https://archive.org/embed/"+id).put("imageUrl","https://archive.org/services/img/"+id));
        }
        return new JSONObject().put("query",MovieQuery.clean(term)).put("page",page).put("total",Math.max(0,response.optLong("numFound",0))).put("fetchedAt",System.currentTimeMillis()).put("items",items).toString();
    }
    public static String load(String term,String genre,String order,int page)throws Exception{
        page=Math.max(1,Math.min(page,100));URL url=new URL(MovieQuery.url(term,genre,order,page));
        for(int hop=0;hop<3;hop++){
            if(!url.getProtocol().equals("https")||!url.getHost().equals("archive.org"))throw new IOException("Unexpected source redirect");
            HttpURLConnection c=(HttpURLConnection)url.openConnection();c.setConnectTimeout(8000);c.setReadTimeout(8000);c.setInstanceFollowRedirects(false);c.setUseCaches(false);c.setRequestProperty("Accept","application/json");c.setRequestProperty("User-Agent","MwendwaBrowser/1.5 Free Movies Reader");
            try{int status=c.getResponseCode();if(status>=300&&status<400){String next=c.getHeaderField("Location");if(next==null)throw new IOException("Invalid redirect");url=new URL(url,next);continue;}if(status!=200)throw new IOException("Movie source unavailable");
                try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n,total=0;while((n=in.read(b))!=-1){total+=n;if(total>2097152)throw new IOException("Response too large");out.write(b,0,n);}return parse(new String(out.toByteArray(),StandardCharsets.UTF_8),term,page);}
            }finally{c.disconnect();}
        }throw new IOException("Too many redirects");
    }
}
