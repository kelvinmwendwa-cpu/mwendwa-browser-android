package com.mwendwa.browser;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;

/** Bounded RSS reader; external entities and DTDs are never accepted. */
public final class RssFeed {
    public static final class Entry { public String title="",link="",published="",publisher="",traffic=""; }
    public static final class Result { public final List<Entry> entries=new ArrayList<>(); public String updated=""; }
    public static Result parse(byte[] xml)throws Exception{
        for(byte b:xml)if(b==0)throw new IOException("Unsupported feed encoding");
        if(xml.length>2097152)throw new IOException("Feed too large");
        String raw=new String(xml,StandardCharsets.UTF_8).toUpperCase(Locale.ROOT);
        if(raw.contains("<!DOCTYPE")||raw.contains("<!ENTITY"))throw new IOException("Unsafe feed declarations");
        Result result=new Result();SAXParserFactory factory=SAXParserFactory.newInstance();factory.setNamespaceAware(true);
        XMLReader reader=factory.newSAXParser().getXMLReader();
        try{reader.setFeature("http://xml.org/sax/features/external-general-entities",false);}catch(SAXException ignored){}
        try{reader.setFeature("http://xml.org/sax/features/external-parameter-entities",false);}catch(SAXException ignored){}
        reader.setEntityResolver((publicId,systemId)->new InputSource(new StringReader("")));
        reader.setContentHandler(new DefaultHandler(){
            int depth=0,itemDepth=-1,fieldDepth=-1;Entry entry;String field="";StringBuilder text=new StringBuilder();
            private String name(String local,String qualified){return local.isEmpty()?qualified.substring(qualified.indexOf(':')+1):local;}
            @Override public void startElement(String uri,String local,String qualified,Attributes a){depth++;String n=name(local,qualified);
                if(n.equals("item")&&entry==null){entry=new Entry();itemDepth=depth;}
                else if(entry!=null&&depth==itemDepth+1&&Arrays.asList("title","link","pubDate","source","approx_traffic").contains(n)){field=n;fieldDepth=depth;text.setLength(0);}
                else if(entry==null&&n.equals("lastBuildDate")){field=n;fieldDepth=depth;text.setLength(0);}
            }
            @Override public void characters(char[] chars,int start,int length){if(fieldDepth>0&&text.length()<16384)text.append(chars,start,Math.min(length,16384-text.length()));}
            @Override public void endElement(String uri,String local,String qualified){String n=name(local,qualified);
                if(depth==fieldDepth){String value=text.toString().trim();if(entry!=null){switch(field){case "title":entry.title=value;break;case "link":entry.link=value;break;case "pubDate":entry.published=value;break;case "source":entry.publisher=value;break;case "approx_traffic":entry.traffic=value;break;}}else if(field.equals("lastBuildDate"))result.updated=value;field="";fieldDepth=-1;}
                if(n.equals("item")&&depth==itemDepth&&entry!=null){if(!entry.title.isEmpty()&&result.entries.size()<24)result.entries.add(entry);entry=null;itemDepth=-1;}depth--;
            }
        });
        reader.parse(new InputSource(new ByteArrayInputStream(xml)));return result;
    }
}
