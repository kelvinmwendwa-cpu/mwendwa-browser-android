package com.mwendwa.browser;
import java.net.*;
import java.util.*;

public final class MovieQuery {
    private static final String[] LICENSES={
        "http://creativecommons.org/publicdomain/mark/1.0/","https://creativecommons.org/publicdomain/mark/1.0/",
        "http://creativecommons.org/publicdomain/zero/1.0/","https://creativecommons.org/publicdomain/zero/1.0/",
        "http://creativecommons.org/licenses/publicdomain/","https://creativecommons.org/licenses/publicdomain/"};
    public static String clean(String input){if(input==null)return "";return input.substring(0,Math.min(input.length(),100)).replaceAll("[^\\p{L}\\p{N}\\s'-]"," ").trim().replaceAll("\\s+"," ");}
    public static String query(String term,String genre){
        StringBuilder q=new StringBuilder("mediatype:movies AND collection:feature_films AND (");
        for(int i=0;i<LICENSES.length;i++){if(i>0)q.append(" OR ");q.append("licenseurl:\"").append(LICENSES[i]).append("\"");}q.append(") AND (format:\"MPEG4\" OR format:\"h.264\" OR format:\"512Kb MPEG4\")");
        String search=clean(term);if(!search.isEmpty())q.append(" AND title:\"").append(search).append("\"");
        String subject="";
        if(genre!=null)switch(genre){case "comedy":subject="subject:comedy";break;case "drama":subject="subject:drama";break;case "horror":subject="subject:horror";break;case "animation":subject="subject:animation";break;case "scifi":subject="(subject:\"science fiction\" OR subject:\"sci-fi\")";break;}
        if(!subject.isEmpty())q.append(" AND ").append(subject);return q.toString();
    }
    public static String license(String url){
        try{URI u=new URI(url);if(!(u.getScheme().equalsIgnoreCase("http")||u.getScheme().equalsIgnoreCase("https"))||!"creativecommons.org".equalsIgnoreCase(u.getHost())||u.getUserInfo()!=null||u.getPort()!=-1||u.getQuery()!=null||u.getFragment()!=null)return "";
            String p=u.getPath();if(p.endsWith("/"))p=p.substring(0,p.length()-1);
            if(p.equals("/publicdomain/zero/1.0"))return "CC0 (source-listed)";
            if(p.equals("/publicdomain/mark/1.0")||p.equals("/licenses/publicdomain"))return "Public domain (source-listed)";
        }catch(Exception ignored){}return "";
    }
    public static String url(String term,String genre,String order,int page)throws Exception{
        String sort="recent".equals(order)?"publicdate desc":"downloads desc";
        StringBuilder result=new StringBuilder("https://archive.org/advancedsearch.php?q=").append(URLEncoder.encode(query(term,genre),"UTF-8"));
        result.append("&output=json&rows=8&page=").append(Math.max(1,Math.min(page,100))).append("&sort%5B%5D=").append(URLEncoder.encode(sort,"UTF-8"));
        for(String field:Arrays.asList("identifier","title","year","creator","licenseurl"))result.append("&fl%5B%5D=").append(field);
        return result.toString();
    }
}
