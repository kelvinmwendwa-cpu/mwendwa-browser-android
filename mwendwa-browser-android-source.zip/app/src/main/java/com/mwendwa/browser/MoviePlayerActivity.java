package com.mwendwa.browser;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.media.*;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.util.*;
import java.util.concurrent.*;

public final class MoviePlayerActivity extends Activity {
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private Future<?> pending;
    private VideoView video;
    private LinearLayout root,header,options,controls;
    private FrameLayout screen;
    private Button exitFull;
    private MediaController mediaController;
    private TextView title,status,clock;
    private ProgressBar busy;
    private Button play,full;
    private SeekBar seek;
    private Spinner files;
    private MovieStreams.Film film;
    private String id;
    private int selected=0,generation=0,resumeAt=0;
    private boolean ready=false,dragging=false,fullscreen=false,active=true,wantPlay=true;
    private static final int BG=0xff0b1423,GOLD=0xffd6b579,WHITE=0xfff4f0e8;
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
    private TextView text(String value,int size,int color){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);t.setPadding(dp(16),dp(8),dp(16),dp(8));return t;}
    private Button button(String label,Runnable action){Button b=new Button(this);b.setText(label);b.setTextSize(12);b.setAllCaps(false);b.setMinHeight(dp(48));b.setTextColor(WHITE);b.setOnClickListener(v->action.run());return b;}
    @Override public void onCreate(Bundle state){super.onCreate(state);id=getIntent().getStringExtra("id");if(!MovieStreams.validId(id)){finish();return;}if(state!=null)resumeAt=state.getInt("position",0);setVolumeControlStream(AudioManager.STREAM_MUSIC);build();resolve();}
    private void build(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
        root.setOnApplyWindowInsetsListener((v,insets)->{if(Build.VERSION.SDK_INT>=30){android.graphics.Insets b=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());v.setPadding(b.left,b.top,b.right,b.bottom);}else v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;});setContentView(root);
        header=new LinearLayout(this);header.setOrientation(LinearLayout.VERTICAL);header.addView(button("‹ Back to movies",()->finish()));title=text(getIntent().getStringExtra("title"),19,GOLD);title.setMaxLines(2);header.addView(title);root.addView(header);
        screen=new FrameLayout(this);screen.setBackgroundColor(Color.BLACK);video=new VideoView(this);video.setKeepScreenOn(true);screen.addView(video,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));busy=new ProgressBar(this);screen.addView(busy,new FrameLayout.LayoutParams(dp(40),dp(40),Gravity.CENTER));exitFull=button("Exit full",()->setFullscreen(false));exitFull.setVisibility(View.GONE);FrameLayout.LayoutParams exitParams=new FrameLayout.LayoutParams(dp(90),dp(48),Gravity.TOP|Gravity.END);exitParams.setMargins(dp(6),dp(6),dp(6),dp(6));screen.addView(exitFull,exitParams);root.addView(screen,new LinearLayout.LayoutParams(-1,0,1));
        status=text("Connecting to the movie source…",12,GOLD);status.setMaxLines(3);root.addView(status);
        seek=new SeekBar(this);seek.setMax(1000);seek.setEnabled(false);root.addView(seek,new LinearLayout.LayoutParams(-1,dp(36)));clock=text("00:00 / 00:00",12,WHITE);clock.setGravity(Gravity.CENTER);root.addView(clock);
        controls=new LinearLayout(this);play=button("▶ Play",()->togglePlay());play.setEnabled(false);controls.addView(play,new LinearLayout.LayoutParams(0,dp(50),1));controls.addView(button("−10s",()->jump(-10000)),new LinearLayout.LayoutParams(0,dp(50),1));controls.addView(button("+10s",()->jump(10000)),new LinearLayout.LayoutParams(0,dp(50),1));full=button("Full screen",()->setFullscreen(!fullscreen));full.setEnabled(false);controls.addView(full,new LinearLayout.LayoutParams(0,dp(50),1));root.addView(controls);
        options=new LinearLayout(this);options.setOrientation(LinearLayout.VERTICAL);files=new Spinner(this);files.setContentDescription("Choose a movie file; smaller files usually use less data");options.addView(files,new LinearLayout.LayoutParams(-1,dp(48)));
        LinearLayout actions=new LinearLayout(this);actions.addView(button("Retry",()->{if(film==null)resolve();else openFile(true);}),new LinearLayout.LayoutParams(0,dp(48),1));actions.addView(button("Open source",()->{Intent intent=new Intent(this,MainActivity.class);intent.setAction(Intent.ACTION_VIEW);intent.setData(Uri.parse("https://archive.org/details/"+id));intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(intent);finish();}),new LinearLayout.LayoutParams(0,dp(48),1));options.addView(actions);options.addView(text("Choose a file above if playback fails. Use your phone’s volume buttons.",11,0xff9baac0));root.addView(options);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar s){dragging=true;}public void onProgressChanged(SeekBar s,int p,boolean user){if(user&&ready)clock.setText(format((int)((long)video.getDuration()*p/1000))+" / "+format(video.getDuration()));}public void onStopTrackingTouch(SeekBar s){if(ready)video.seekTo((int)((long)Math.max(0,video.getDuration())*s.getProgress()/1000));dragging=false;}});
        video.setOnPreparedListener(mp->{ready=true;busy.setVisibility(View.GONE);play.setEnabled(true);full.setEnabled(true);seek.setEnabled(true);if(resumeAt>0){video.seekTo(resumeAt);resumeAt=0;}if(active&&wantPlay){video.start();play.setText("❚❚ Pause");status.setText("Playing");}else status.setText("Ready · tap Play");});
        video.setOnInfoListener((mp,what,extra)->{if(what==MediaPlayer.MEDIA_INFO_BUFFERING_START){busy.setVisibility(View.VISIBLE);status.setText("Buffering from the source…");}if(what==MediaPlayer.MEDIA_INFO_BUFFERING_END||what==MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START){busy.setVisibility(View.GONE);status.setText(video.isPlaying()?"Playing":"Paused");}return false;});
        video.setOnErrorListener((mp,what,extra)->{generation++;if(fullscreen)setFullscreen(false);full.setEnabled(false);ready=false;busy.setVisibility(View.GONE);play.setEnabled(false);seek.setEnabled(false);status.setText("This file could not play. Try another file, Retry, or Open source.");return true;});
        video.setOnCompletionListener(mp->{wantPlay=false;play.setText("▶ Replay");status.setText("Finished");busy.setVisibility(View.GONE);});
        handler.post(tick);
    }
    private final Runnable tick=new Runnable(){public void run(){if(isDestroyed())return;if(active&&ready&&!dragging){int duration=video.getDuration(),position=video.getCurrentPosition();if(duration>0)seek.setProgress((int)((long)position*1000/duration));seek.setSecondaryProgress(video.getBufferPercentage()*10);clock.setText(format(position)+" / "+format(duration));play.setText(video.isPlaying()?"❚❚ Pause":"▶ Play");}handler.postDelayed(this,1000);}};
    private String format(int millis){int seconds=Math.max(0,millis/1000);return seconds>=3600?String.format(Locale.ROOT,"%d:%02d:%02d",seconds/3600,(seconds/60)%60,seconds%60):String.format(Locale.ROOT,"%02d:%02d",seconds/60,seconds%60);}
    private void resolve(){
        final int request=++generation;if(pending!=null)pending.cancel(true);busy.setVisibility(View.VISIBLE);status.setText("Finding a playable movie file…");ready=false;play.setEnabled(false);full.setEnabled(false);seek.setEnabled(false);
        handler.postDelayed(()->{if(request==generation&&film==null&&!isDestroyed())status.setText("The source is taking longer. You can Retry or go Back.");},8000);
        pending=worker.submit(()->{try{MovieStreams.Film found=MovieStreams.load(id);runOnUiThread(()->{if(request!=generation||isDestroyed())return;film=found;title.setText(found.title);ArrayList<String> labels=new ArrayList<>();for(MovieStreams.Stream s:film.streams)labels.add(s.label);selected=0;files.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,labels));files.setSelection(0);files.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> parent){}public void onItemSelected(android.widget.AdapterView<?> parent,View view,int position,long itemId){if(position!=selected){selected=position;resumeAt=0;openFile(false);}}});openFile(false);});}catch(Exception e){runOnUiThread(()->{if(request!=generation||isDestroyed())return;generation++;busy.setVisibility(View.GONE);status.setText(e instanceof java.io.IOException?e.getMessage():"Could not read the source. Retry or choose another film.");});}});
    }
    private void openFile(boolean retry){if(film==null||film.streams.isEmpty())return;if(retry&&ready)resumeAt=video.getCurrentPosition();ready=false;play.setEnabled(false);full.setEnabled(false);seek.setEnabled(false);busy.setVisibility(View.VISIBLE);wantPlay=true;status.setText("Opening movie stream…");video.stopPlayback();video.setVideoURI(Uri.parse(film.streams.get(selected).url));
        final int request=++generation;handler.postDelayed(()->{if(request==generation&&!ready&&!isDestroyed())status.setText("Still loading from the source. Try a smaller file or Retry.");},15000);
    }
    private void togglePlay(){if(!ready)return;if(video.isPlaying()){wantPlay=false;video.pause();status.setText("Paused");}else{wantPlay=true;video.start();status.setText("Playing");}play.setText(video.isPlaying()?"❚❚ Pause":"▶ Play");}
    private void jump(int amount){if(ready)video.seekTo(Math.max(0,Math.min(video.getDuration(),video.getCurrentPosition()+amount)));}
    private void setFullscreen(boolean value){
        if(ready)resumeAt=video.getCurrentPosition();fullscreen=value;int visibility=value?View.GONE:View.VISIBLE;header.setVisibility(visibility);options.setVisibility(visibility);status.setVisibility(visibility);clock.setVisibility(visibility);seek.setVisibility(visibility);controls.setVisibility(visibility);exitFull.setVisibility(value?View.VISIBLE:View.GONE);
        if(value){if(mediaController==null)mediaController=new MediaController(this);mediaController.setAnchorView(screen);video.setMediaController(mediaController);mediaController.show(4000);}else{if(mediaController!=null)mediaController.hide();video.setMediaController(null);}
        if(Build.VERSION.SDK_INT>=30){WindowInsetsController controller=getWindow().getInsetsController();if(controller!=null){if(value){controller.hide(WindowInsets.Type.systemBars());controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);}else controller.show(WindowInsets.Type.systemBars());}}else getWindow().getDecorView().setSystemUiVisibility(value?View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY:View.SYSTEM_UI_FLAG_VISIBLE);
        setRequestedOrientation(value?ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE:ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
    }
    @Override public void onBackPressed(){if(fullscreen)setFullscreen(false);else super.onBackPressed();}
    @Override protected void onPause(){active=false;wantPlay=false;if(ready){resumeAt=video.getCurrentPosition();video.pause();status.setText("Paused · tap Play to resume");}super.onPause();}
    @Override protected void onResume(){super.onResume();active=true;}
    @Override protected void onSaveInstanceState(Bundle state){state.putInt("position",ready?video.getCurrentPosition():resumeAt);super.onSaveInstanceState(state);}
    @Override protected void onDestroy(){generation++;if(pending!=null)pending.cancel(true);worker.shutdownNow();handler.removeCallbacksAndMessages(null);if(mediaController!=null)mediaController.hide();if(video!=null)video.stopPlayback();super.onDestroy();}
}
