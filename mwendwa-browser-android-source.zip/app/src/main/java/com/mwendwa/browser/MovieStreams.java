package com.mwendwa.browser;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.*;

/** Resolve public, source-labelled film metadata to compatible MP4 files. */
public final class MovieStreams {
    public static final class Stream { public String name,url,label; public long size; public double seconds; public boolean h264; }
    public static final class Film { public String title,id; public final List<Stream> streams=new ArrayList<>(); }
    private static String text(JSONObject o,String key){Object v=o.opt(key);return v instanceof JSONArray?((JSONArray)v).optString(0,""):v==null||v==JSONObject.NULL?"":String.valueOf(v);}
    private static String encoded(String value)throws Exception{return URLEncoder.encode(value,"UTF-8").replace("+","%20");}
    public static boolean validId(String id){return id!=null&&id.matches("[A-Za-z0-9][A-Za-z0-9_.-]{0,199}");}
    public static Film parse(String id,String json)throws Exception{
        if(!validId(id))throw new IOException("Invalid movie identifier.");
        JSONObject root=new JSONObject(json),meta=root.optJSONObject("metadata");
        if(meta==null||!"movies".equals(text(meta,"mediatype"))||MovieQuery.license(text(meta,"licenseurl")).isEmpty())throw new IOException("This source listing cannot be verified for this catalog.");
        if(root.optBoolean("is_dark",false)||"true".equalsIgnoreCase(text(meta,"access-restricted-item")))throw new IOException("This source file is not publicly available.");
        boolean filmCollection=false;Object collection=meta.opt("collection");if(collection instanceof JSONArray){JSONArray a=(JSONArray)collection;for(int i=0;i<a.length();i++)if("feature_films".equals(a.optString(i)))filmCollection=true;}else filmCollection="feature_films".equals(String.valueOf(collection));
        if(!filmCollection)throw new IOException("This item is outside the movie catalog.");
        Film film=new Film();film.id=id;film.title=text(meta,"title");JSONArray files=root.optJSONArray("files");
        if(files!=null)for(int i=0;i<files.length();i++){JSONObject f=files.optJSONObject(i);if(f==null)continue;String name=f.optString("name","");String lower=name.toLowerCase(Locale.ROOT);
            if(!lower.endsWith(".mp4")||name.contains("\\")||name.startsWith("/")||name.contains("../")||name.length()>500||f.optBoolean("private",false))continue;
            Stream s=new Stream();s.h264=f.optString("format","").toLowerCase(Locale.ROOT).contains("h.264");s.name=name;s.size=f.optLong("size",0);try{s.seconds=Double.parseDouble(f.optString("length","0"));}catch(Exception ignored){s.seconds=0;}if(!Double.isFinite(s.seconds)||s.seconds<0)s.seconds=0;
            StringBuilder path=new StringBuilder();for(String segment:name.split("/")){if(segment.isEmpty()||segment.equals(".")||segment.equals(".."))throw new IOException("Invalid source file path.");if(path.length()>0)path.append('/');path.append(encoded(segment));}
            s.url="https://archive.org/download/"+id+"/"+path;
            String dimensions=f.optString("width","");if(!dimensions.isEmpty())dimensions+="×"+f.optString("height","?")+" · ";
            s.label=dimensions+(s.size>0?String.format(Locale.ROOT,"%.0f MB · ",s.size/1048576.0):"")+name;
            film.streams.add(s);
        }
        if(film.streams.isEmpty())throw new IOException("No playable MP4 file is currently listed. Choose another film.");
        // Prefer longer tracks, explicitly labelled H.264, then the smaller file.
        double max=0;for(Stream s:film.streams)max=Math.max(max,s.seconds);final double longest=max;
        film.streams.sort((a,b)->{boolean af=longest>0&&a.seconds>=longest*0.9,bf=longest>0&&b.seconds>=longest*0.9;if(af!=bf)return af?-1:1;if(a.h264!=b.h264)return a.h264?-1:1;long as=a.size>0?a.size:Long.MAX_VALUE,bs=b.size>0?b.size:Long.MAX_VALUE;return Long.compare(as,bs);});
        return film;
    }
    public static Film load(String id)throws Exception{
        if(!validId(id))throw new IOException("Invalid movie identifier.");URL url=new URL("https://archive.org/metadata/"+id);
        for(int hop=0;hop<3;hop++){
            if(!"https".equals(url.getProtocol())||!"archive.org".equals(url.getHost()))throw new IOException("Unexpected source redirect.");
            HttpURLConnection c=(HttpURLConnection)url.openConnection();c.setConnectTimeout(8000);c.setReadTimeout(8000);c.setInstanceFollowRedirects(false);c.setRequestProperty("Accept","application/json");c.setRequestProperty("User-Agent","MwendwaBrowser/1.5 Movie Player");
            try{int status=c.getResponseCode();if(status>=300&&status<400){String next=c.getHeaderField("Location");if(next==null)throw new IOException("Invalid source redirect.");url=new URL(url,next);continue;}if(status!=200)throw new IOException("The movie source is unavailable. Try again.");
                try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n,total=0;while((n=in.read(b))!=-1){if(Thread.currentThread().isInterrupted())throw new IOException("Cancelled");total+=n;if(total>4194304)throw new IOException("Source metadata is too large.");out.write(b,0,n);}return parse(id,new String(out.toByteArray(),StandardCharsets.UTF_8));}
            }finally{c.disconnect();}
        }throw new IOException("The source redirected too many times.");
    }
}
