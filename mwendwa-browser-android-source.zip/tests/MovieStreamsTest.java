import com.mwendwa.browser.MovieStreams;
import java.nio.file.*;
import org.json.*;
public class MovieStreamsTest {
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 static JSONObject base(){return new JSONObject().put("metadata",new JSONObject().put("title","Test film").put("mediatype","movies").put("licenseurl","https://creativecommons.org/publicdomain/mark/1.0/").put("collection",new JSONArray().put("feature_films")));}
 public static void main(String[] args)throws Exception{
  JSONArray files=new JSONArray().put(new JSONObject().put("name","full large.mp4").put("size","200000000").put("length","1200")).put(new JSONObject().put("name","full smaller.mp4").put("size","100000000").put("length","1200")).put(new JSONObject().put("name","trailer.mp4").put("size","1000000").put("length","30")).put(new JSONObject().put("name","../bad.mp4")).put(new JSONObject().put("name","private.mp4").put("private",true)).put(new JSONObject().put("name","other.avi"));
  MovieStreams.Film film=MovieStreams.parse("test-film",base().put("files",files).toString());check(film.streams.size()==3,"unsafe/private/unsupported skipped");check(film.streams.get(0).name.equals("full smaller.mp4"),"smaller full-length file first");check(film.streams.get(0).url.equals("https://archive.org/download/test-film/full%20smaller.mp4"),"safe encoded source URL");
  files.getJSONObject(0).put("format","h.264");MovieStreams.Film compatible=MovieStreams.parse("test-film",base().put("files",files).toString());check(compatible.streams.get(0).name.equals("full large.mp4"),"explicit H264 prioritized");
  boolean failed=false;try{MovieStreams.parse("../bad",base().toString());}catch(Exception e){failed=true;}check(failed,"bad ID rejected");failed=false;try{MovieStreams.parse("test-film",base().put("files",new JSONArray()).toString());}catch(Exception e){failed=e.getMessage().contains("No playable MP4");}check(failed,"clear missing-file error");
  failed=false;try{MovieStreams.parse("test-film",base().put("is_dark",true).put("files",files).toString());}catch(Exception e){failed=true;}check(failed,"unavailable source rejected");
  failed=false;try{MovieStreams.parse("HisNewJobCharlesChaplin-1915",Files.readString(Paths.get(args[0])));}catch(Exception e){failed=e.getMessage().contains("No playable MP4");}check(failed,"actual missing-video listing rejected");
  if(args.length>1){film=MovieStreams.parse("his_girl_friday",Files.readString(Paths.get(args[1])));check(!film.streams.isEmpty(),"live MP4 found");Files.writeString(Paths.get(args[2]),film.streams.get(0).url);System.out.println("Resolved live movie: "+film.title+"; MP4 choices: "+film.streams.size()+"; default "+film.streams.get(0).label);}
  System.out.println("Stream selection, source gating, path validation and missing-file checks passed.");
 }
}
