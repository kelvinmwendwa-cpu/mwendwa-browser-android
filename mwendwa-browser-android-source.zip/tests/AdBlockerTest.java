import com.mwendwa.browser.AdBlocker;
import java.io.*;
import java.nio.charset.StandardCharsets;
public class AdBlockerTest {
    private static void check(boolean condition,String name){if(!condition)throw new AssertionError(name);}
    public static void main(String[] args)throws Exception{
        String fixture="# comment\n127.0.0.1 ads.example.com # ad host\n0.0.0.0 tracker.example.org alias.example.org\n::1 localhost\nnot-an-ip innocent.example.org\n";
        AdBlocker b=new AdBlocker(new ByteArrayInputStream(fixture.getBytes(StandardCharsets.UTF_8)));
        check(b.blocks("ads.example.com"),"exact host");
        check(b.blocks("cdn.ads.example.com"),"subdomain");
        check(b.blocks("ADS.EXAMPLE.COM."),"case and trailing dot");
        check(b.blocks("alias.example.org"),"multiple names");
        check(!b.blocks("notads.example.com"),"sibling boundary");
        check(!b.blocks("ads.example.com.evil.org"),"suffix confusion");
        check(!b.blocks("example.com"),"parent remains available");
        check(!b.blocks("innocent.example.org"),"bad record ignored");
        check(!b.blocks("localhost")&&!b.blocks(null),"local and null");
        check(b.blocks("pagead2.googlesyndication.com"),"bundled extra rule");
        AdBlocker real=new AdBlocker(new FileInputStream(args[0]));
        check(real.size()>5000,"real list present");
        check(real.blocks("ad.doubleclick.net"),"real ads blocked");
        check(!real.blocks("www.wikipedia.org")&&!real.blocks("www.google.com"),"content hosts allowed");
        System.out.println("13 ad-host checks passed; bundled rules: "+real.size());
    }
}
