import com.mwendwa.browser.ArchiveMovies;
import org.json.*;
import java.nio.file.*;
public class ArchiveMoviesTest {
 public static void main(String[] args)throws Exception{
  String catalog=Files.readString(Paths.get(args[0]));JSONObject result=new JSONObject(ArchiveMovies.parse(catalog,"",1));JSONArray items=result.getJSONArray("items");if(items.length()==0)throw new AssertionError("Live catalog has valid results");
  for(int i=0;i<items.length();i++){JSONObject row=items.getJSONObject(i);if(!row.getString("watchUrl").startsWith("https://archive.org/embed/"))throw new AssertionError("Unexpected player source");}
  String fixture="{\"response\":{\"numFound\":3,\"docs\":[{\"identifier\":\"../evil\",\"title\":\"Bad ID\",\"licenseurl\":\"https://creativecommons.org/publicdomain/mark/1.0/\"},{\"identifier\":\"bad-license\",\"title\":\"Wrong license\",\"licenseurl\":\"https://evil.example/\"},{\"identifier\":\"good-film\",\"title\":\"<script>title</script>\",\"licenseurl\":\"http://creativecommons.org/publicdomain/zero/1.0/\",\"creator\":[\"Creator one\",\"Creator two\"]}]}}";
  JSONArray safe=new JSONObject(ArchiveMovies.parse(fixture,"",1)).getJSONArray("items");if(safe.length()!=1||!safe.getJSONObject(0).getString("creator").equals("Creator one")||!safe.getJSONObject(0).getString("licenseUrl").startsWith("https:"))throw new AssertionError("Metadata validation failed");
  Files.writeString(Paths.get(args[1]),result.toString());System.out.println("Parsed "+items.length()+" live catalog results; unsafe IDs/licenses rejected and source URLs constrained.");
 }
}
