import com.mwendwa.browser.MovieQuery;
import java.net.*;
public class MovieQueryTest {
 private static void check(boolean b,String name){if(!b)throw new AssertionError(name);}
 public static void main(String[] args)throws Exception{
  String q=MovieQuery.query("Night of the Living Dead","horror");check(q.contains("mediatype:movies AND collection:feature_films"),"fixed collection");check(q.contains("licenseurl:"),"fixed license gate");check(q.contains("title:\"Night of the Living Dead\""),"quoted title");check(q.endsWith("subject:horror"),"known genre");
  String injected=MovieQuery.query("\") OR *:* OR (\"","subject:anything");check(!injected.contains("*:*"),"operator stripped");check(injected.contains("AND title:\"OR OR\""),"input remains inside title");
  check(MovieQuery.clean("a".repeat(200)).length()==100,"query bound");check(MovieQuery.license("http://creativecommons.org/publicdomain/mark/1.0/").startsWith("Public domain"),"PD allowed");check(MovieQuery.license("https://creativecommons.org/publicdomain/zero/1.0/").startsWith("CC0"),"CC0 allowed");
  check(MovieQuery.license("https://creativecommons.org.evil.example/publicdomain/mark/1.0/").isEmpty(),"license host boundary");check(MovieQuery.license("https://creativecommons.org/licenses/by/4.0/").isEmpty(),"other licensing excluded");check(MovieQuery.license("https://creativecommons.org/publicdomain/mark/1.0/?x=y").isEmpty(),"ambiguous license excluded");
  String url=MovieQuery.url("Alien","all","bad-sort",999);check(url.startsWith("https://archive.org/advancedsearch.php?"),"fixed endpoint");check(url.contains("page=100"),"page bound");check(URLDecoder.decode(url,"UTF-8").contains("sort[]=downloads desc"),"sort enum");
  check(q.contains("format:\"MPEG4\""),"MP4 listing filter");check(url.contains("rows=8"),"smaller page size");System.out.println("17 movie query/license safety checks passed.");
 }
}
