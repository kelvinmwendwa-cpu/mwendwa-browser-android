import com.mwendwa.browser.RssFeed;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
public class RssFeedTest {
 private static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 public static void main(String[] args)throws Exception{
 String fixture="<rss xmlns:ht='urn:test'><channel><title>Channel title</title><lastBuildDate>Today</lastBuildDate><item><title>A &amp; B</title><link>https://example.com/article</link><pubDate>Yesterday</pubDate><source>Publisher</source><ht:approx_traffic>2K+</ht:approx_traffic><ht:news_item><ht:title>Nested story</ht:title></ht:news_item></item></channel></rss>";
 RssFeed.Result r=RssFeed.parse(fixture.getBytes(StandardCharsets.UTF_8));check(r.entries.size()==1,"one item");check(r.entries.get(0).title.equals("A & B"),"nested title excluded and XML decoded");check(r.entries.get(0).publisher.equals("Publisher"),"publisher");check(r.entries.get(0).traffic.equals("2K+"),"namespaced traffic");check(r.updated.equals("Today"),"source timestamp");
 boolean rejected=false;try{RssFeed.parse("<!DOCTYPE rss [<!ENTITY x SYSTEM 'file:///etc/passwd'>]><rss>&x;</rss>".getBytes(StandardCharsets.UTF_8));}catch(Exception e){rejected=true;}check(rejected,"DTD rejected");
 rejected=false;try{RssFeed.parse(fixture.getBytes(StandardCharsets.UTF_16));}catch(Exception e){rejected=true;}check(rejected,"unsupported encoding rejected");
 for(String file:args){r=RssFeed.parse(Files.readAllBytes(Paths.get(file)));check(!r.entries.isEmpty(),"live source items present: "+file);System.out.println(file+": parsed "+r.entries.size()+" live items");}
 System.out.println("RSS parser security, metadata, nested content and live-source checks passed.");
 }
}
