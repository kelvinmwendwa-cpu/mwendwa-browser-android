"""Build a personally signed APK without Gradle. Requires JDK 17 and SDK 35.
Usage: python build_apk.py /path/to/Android/Sdk
"""
from pathlib import Path
import os, shutil, subprocess, sys, zipfile
root=Path(__file__).resolve().parent
sdk=Path(sys.argv[1] if len(sys.argv)>1 else os.environ.get('ANDROID_SDK_ROOT',os.environ.get('ANDROID_HOME',''))).resolve()
bt=sdk/'build-tools'/'35.0.0'
android=sdk/'platforms'/'android-35'/'android.jar'
if not android.exists(): raise SystemExit('Install Android SDK Platform 35 and Build Tools 35.0.0 first.')
build=root/'build'/'manual'
if build.exists(): shutil.rmtree(build)
for name in ['classes','dex','gen']: (build/name).mkdir(parents=True)
def run(*args): subprocess.run([str(a) for a in args],check=True,cwd=root)
def tool(name): return bt/(name+('.bat' if name in ('d8','apksigner') else '.exe') if os.name=='nt' else name)
manifest=(root/'app/src/main/AndroidManifest.xml').read_text().replace('<manifest xmlns:', '<manifest package="com.mwendwa.browser" xmlns:')
(build/'AndroidManifest.xml').write_text(manifest)
run(tool('aapt2'),'compile','--dir',root/'app/src/main/res','-o',build/'res.zip')
run(tool('aapt2'),'link','-o',build/'base.apk','-I',android,'--manifest',build/'AndroidManifest.xml','--java',build/'gen','--min-sdk-version','29','--target-sdk-version','35','--version-code','7','--version-name','1.6','-A',root/'app/src/main/assets',build/'res.zip')
run('java','com.sun.tools.javac.Main','-source','17','-target','17','-classpath',android,'-d',build/'classes',*sorted((root/'app/src/main/java').rglob('*.java')))
run(tool('d8'),'--lib',android,'--min-api','29','--output',build/'dex',*sorted((build/'classes').rglob('*.class')))
with zipfile.ZipFile(build/'base.apk','a',zipfile.ZIP_DEFLATED) as apk:
    for dex in (build/'dex').glob('*.dex'): apk.write(dex,dex.name)
run(tool('zipalign'),'-f','-p','4',build/'base.apk',build/'aligned.apk')
properties=dict(line.split('=',1) for line in (root/'signing/signing.properties').read_text().splitlines() if '=' in line)
output=root/'MwendwaBrowser.apk'
# Pass signing passwords through environment variables so they are not in process arguments.
os.environ['MWENDWA_STORE_PASS']=properties['storePassword'];os.environ['MWENDWA_KEY_PASS']=properties['keyPassword']
run(tool('apksigner'),'sign','--ks',root/'signing/mwendwa.jks','--ks-key-alias',properties['keyAlias'],'--ks-pass','env:MWENDWA_STORE_PASS','--key-pass','env:MWENDWA_KEY_PASS','--out',output,build/'aligned.apk')
run(tool('apksigner'),'verify','--verbose',output)
run(tool('zipalign'),'-c','-v','4',output)
print('APK ready:',output)
